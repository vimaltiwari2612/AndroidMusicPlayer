package com.example.musicplayer;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.BitmapFactory;
import android.graphics.drawable.Drawable;
import android.media.MediaMetadataRetriever;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private List<File> songs;
    protected File[] songsArray;
    private static int STORAGE_PERMISSION_CODE = 100;
    private ListView playlist;
    private SongsList<File> songListAdapter;
    private MediaPlayer mediaPlayer;
    private ImageButton play_pause, next, previous;
    private int currentIndex = 0;
    private TextView playingSong;
    private SeekBar seekBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        checkPermission(
                Manifest.permission.READ_EXTERNAL_STORAGE,
                STORAGE_PERMISSION_CODE);
    }

    private void init(){
        mediaPlayer = getMediaPlayerInstance();
        playlist = findViewById(R.id.playlist);
        playingSong = (TextView) findViewById(R.id.playingSong);
        seekBar = (SeekBar) findViewById(R.id.seekBar);
        songs = getSongsList(Environment.getExternalStorageDirectory());
        populatePlaylist();
        populateMediaControls();
    }

    private void populatePlaylist(){
        songsArray = new File[songs.size()];

        for(int i=0;i<songs.size();i++){
            songsArray[i] = songs.get(i);
        }
        songListAdapter = new SongsList<File>(this,R.layout.activity_main,songsArray);
        playlist.setAdapter(songListAdapter);
        playlist.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                play(songsArray[position]);
                currentIndex = position;
            }
        });
    }


    private List<File> getSongsList(File file){
        List<File> toBeReturnedFiles = new ArrayList<File>();
        File[] files = file.listFiles();
        if(files != null) {
            for (File f : files) {
                if(!f.isHidden()) {
                    if (f.isDirectory()) {
                        toBeReturnedFiles.addAll(getSongsList(f));
                    } else {
                        String fileName = f.getName();
                        if (fileName.endsWith(".mp3")) {
                            toBeReturnedFiles.add(f);
                        }
                    }
                }
            }
        }
        return toBeReturnedFiles;
    }

    private String getDuration(String duration){
        long dur = Long.parseLong(duration);
        String txtTime = "";
        if(duration != null) {
            // convert duration to minute:seconds
            String seconds = String.valueOf((dur % 60000) / 1000);
            String minutes = String.valueOf(dur / 60000);
            String out = minutes + ":" + seconds;
            if (seconds.length() == 1) {
                txtTime = "0" + minutes + ":0" + seconds;
            } else {
                txtTime = "0" + minutes + ":" + seconds;
            }
        }
        return txtTime;
    }

    // Function to check and request permission.
    public void checkPermission(String permission, int requestCode)
    {
        if (ContextCompat.checkSelfPermission(MainActivity.this, permission)
                == PackageManager.PERMISSION_DENIED) {

            // Requesting the permission
            ActivityCompat.requestPermissions(MainActivity.this,
                    new String[] { permission },
                    requestCode);
        }
        else {
            init();

        }
    }

    // This function is called when the user accepts or decline the permission.
    // Request Code is used to check which permission called this function.
    // This request code is provided when the user is prompt for permission.

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           String[] permissions, int[] grantResults)
    {
        super.onRequestPermissionsResult(requestCode,
                        permissions,
                        grantResults);

        if (requestCode == STORAGE_PERMISSION_CODE) {
            if (grantResults.length > 0
                    && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                init();
            }
            else {
                Toast.makeText(MainActivity.this,
                        "Storage Permission Denied",
                        Toast.LENGTH_SHORT)
                        .show();
            }
        }
    }

    public class SongsList<F> extends ArrayAdapter<File> {


        public SongsList(@NonNull Context context, int resource, @NonNull File[] objects) {
            super(context, resource, objects);
        }

        @NonNull
        @Override
        public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
            File file = getItem(position);
            MediaMetadataRetriever mmr = new MediaMetadataRetriever();
            MainActivity ref = MainActivity.this;
            mmr.setDataSource(file.getAbsolutePath());
            // Check if an existing view is being reused, otherwise inflate the view
            if (convertView == null) {
                convertView = LayoutInflater.from(getContext()).inflate(R.layout.song, parent, false);
            }
            // Lookup view for data population
            TextView songName = (TextView) convertView.findViewById(R.id.songName);
            TextView duration = (TextView) convertView.findViewById(R.id.duration);
            ImageView image = (ImageView) convertView.findViewById(R.id.songImage);
            // Populate the data into the template view using the data object
            songName.setText(file.getName().replace(".mp3",""));
            duration.setText("Duration : "+ref.getDuration(mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)));
            // getting the embedded picture from media
            byte[] art = mmr.getEmbeddedPicture();

            if (art != null) {
                // Convert the byte array to a bitmap
                image.setImageBitmap(BitmapFactory.decodeByteArray(art, 0, art.length));
            }
            else {
                image.setImageResource(R.drawable.ic_baseline_crop_original_24);
            }
// close object
            mmr.release();
            // Return the completed view to render on screen
            return convertView;
        }
    }


    //*****************************************MEDIA CONTROL METHODS******************//

    Thread seekbarProgressThread = new Thread(new Runnable() {
        @Override
        public void run() {
            try {
                while (mediaPlayer.getCurrentPosition() < mediaPlayer.getDuration()) {
                    seekBar.setProgress(mediaPlayer.getCurrentPosition());
                    Thread.sleep(1000);
                }
            }catch (InterruptedException e){
                e.printStackTrace();
            }
        }
    });

    private MediaPlayer getMediaPlayerInstance(){
        if(mediaPlayer == null) mediaPlayer = new MediaPlayer();
        return mediaPlayer;
    }

    private void populateMediaControls(){
        play_pause = (ImageButton) findViewById(R.id.play_pause);
        play_pause.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onClick(View v) {
                mediaPlayer = getMediaPlayerInstance();
                if(mediaPlayer.isPlaying()){
                    mediaPlayer.pause();
                    play_pause.setImageResource(R.drawable.ic_baseline_play_arrow_24);
                }else{
                    mediaPlayer.start();
                    play_pause.setImageResource(R.drawable.pause);
                }
            }
        });


        next = (ImageButton) findViewById(R.id.next);
        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                next();
            }
        });


        previous = (ImageButton) findViewById(R.id.previous);
        previous.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                previous();
            }
        });

        seekBar.setProgress(0);
        seekbarProgressThread.start();
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                mediaPlayer = getMediaPlayerInstance();
                if(mediaPlayer.isPlaying()){
                    mediaPlayer.seekTo(progress);
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });
    }

    private void play(File song) {
        mediaPlayer = getMediaPlayerInstance();
        mediaPlayer.stop();
        mediaPlayer.reset();
        try {
            mediaPlayer.setDataSource(song.getPath());
            playingSong.setText(song.getName().replace(".mp3",""));
            mediaPlayer.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
                @Override
                public void onPrepared(MediaPlayer mp) {
                    seekBar.setProgress(0);
                    seekBar.setMax(mediaPlayer.getDuration());
                    mediaPlayer.start();
                }
            });
            mediaPlayer.prepareAsync();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void next(){
        currentIndex++;
        if(currentIndex == songsArray.length){
            currentIndex = 0;
        }
        play(songsArray[currentIndex]);
    }

    private void previous(){
        currentIndex--;
        if(currentIndex < 0){
            currentIndex = songsArray.length - 1;
        }
        play(songsArray[currentIndex]);
    }


    @Override
    protected void onDestroy() {
        super.onDestroy();
        mediaPlayer.stop();
        mediaPlayer.release();
    }
}